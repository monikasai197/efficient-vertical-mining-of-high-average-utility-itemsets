from django.db.models import Count
from django.shortcuts import render, redirect


# Create your views here.
from admins.models import UploadModel
from user.models import RegisterModel, Two_ProductModel, Three_ProductModel, Four_ProductModel, FeedbackModel


def login(request):
    if request.method == "POST":
        if request.method == "POST":
            usid = request.POST.get('username')
            pswd = request.POST.get('password')
            if usid == 'admin' and pswd == 'admin':
                return redirect('upload_page')
    return render(request,'admins/login.html')

def admin_page(request):
    return render(request,'admins/admin_page.html')

def upload_page(request):
    if request.method=="POST":
        ven=request.POST.get("vendor")
        cste=request.POST.get("category")
        name=request.POST.get("product")
        UploadModel.objects.create(vendor=ven,category=cste,product_name=name)
    return render(request,'admins/upload_page.html')

def view_userdetails(request):
    obj = RegisterModel.objects.all()
    return render(request,'admins/view_userdetails.html',{'objects':obj})

def user_viewfeedback(request):
    obj = FeedbackModel.objects.all()
    return render(request,'admins/user_feedback.html',{'object':obj})

def two_product(request):
    chart = Two_ProductModel.objects.values('pro_name').annotate(dcount=Count('pro_name')).order_by('-dcount')[:5]
    return render(request,'admins/two_product.html',{'obj':chart})

def three_product(request):
    chart = Three_ProductModel.objects.values('pro_names').annotate(dcount=Count('pro_names')).order_by('-dcount')[:5]
    return render(request,'admins/three_product.html',{'obj':chart})

def four_product(request):
    chart = Four_ProductModel.objects.values('pro_namees').annotate(dcount=Count('pro_namees')).order_by('-dcount')[:5]
    return render(request,'admins/four_product.html',{'obj':chart})

def new_page(request):
    obj = FeedbackModel.objects.all()
    return render(request,'admins/new_page.html',{'object':obj})
