from django.db import models

# Create your models here.
class UploadModel(models.Model):
    vendor=models.CharField(max_length=200)
    category=models.CharField(max_length=200)
    product_name=models.CharField(max_length=200)